﻿namespace WindowsFormsApplication1
{
    partial class frm_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			this.panel1 = new System.Windows.Forms.Panel();
			this.minimize = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.pn_padido = new System.Windows.Forms.Panel();
			this.listView1 = new System.Windows.Forms.ListView();
			this.pn_menu = new System.Windows.Forms.Panel();
			this.dgv_Menu = new System.Windows.Forms.DataGridView();
			this.pn_btns = new System.Windows.Forms.Panel();
			this.btn_beb = new System.Windows.Forms.Button();
			this.btn_sob = new System.Windows.Forms.Button();
			this.btn_pr = new System.Windows.Forms.Button();
			this.colNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colValor = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.col_btnAdd = new System.Windows.Forms.DataGridViewButtonColumn();
			this.panel1.SuspendLayout();
			this.pn_padido.SuspendLayout();
			this.pn_menu.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Menu)).BeginInit();
			this.pn_btns.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(963, 25);
			this.panel1.TabIndex = 3;
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.Location = new System.Drawing.Point(913, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 2;
			this.minimize.Text = "_";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.Location = new System.Drawing.Point(938, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 1;
			this.exit.Text = "x";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// pn_padido
			// 
			this.pn_padido.Controls.Add(this.listView1);
			this.pn_padido.Dock = System.Windows.Forms.DockStyle.Right;
			this.pn_padido.Location = new System.Drawing.Point(729, 25);
			this.pn_padido.Name = "pn_padido";
			this.pn_padido.Size = new System.Drawing.Size(234, 486);
			this.pn_padido.TabIndex = 4;
			// 
			// listView1
			// 
			this.listView1.Location = new System.Drawing.Point(3, 101);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(219, 337);
			this.listView1.TabIndex = 0;
			this.listView1.UseCompatibleStateImageBehavior = false;
			// 
			// pn_menu
			// 
			this.pn_menu.Controls.Add(this.dgv_Menu);
			this.pn_menu.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pn_menu.Location = new System.Drawing.Point(0, 81);
			this.pn_menu.Name = "pn_menu";
			this.pn_menu.Size = new System.Drawing.Size(729, 430);
			this.pn_menu.TabIndex = 5;
			// 
			// dgv_Menu
			// 
			this.dgv_Menu.AllowUserToAddRows = false;
			this.dgv_Menu.AllowUserToDeleteRows = false;
			this.dgv_Menu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_Menu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNome,
            this.colValor,
            this.colDesc,
            this.col_btnAdd});
			this.dgv_Menu.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgv_Menu.Location = new System.Drawing.Point(0, 0);
			this.dgv_Menu.Name = "dgv_Menu";
			this.dgv_Menu.ReadOnly = true;
			this.dgv_Menu.Size = new System.Drawing.Size(729, 430);
			this.dgv_Menu.TabIndex = 0;
			this.dgv_Menu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Menu_CellContentClick);
			// 
			// pn_btns
			// 
			this.pn_btns.Controls.Add(this.btn_beb);
			this.pn_btns.Controls.Add(this.btn_sob);
			this.pn_btns.Controls.Add(this.btn_pr);
			this.pn_btns.Dock = System.Windows.Forms.DockStyle.Top;
			this.pn_btns.Location = new System.Drawing.Point(0, 25);
			this.pn_btns.Name = "pn_btns";
			this.pn_btns.Size = new System.Drawing.Size(729, 50);
			this.pn_btns.TabIndex = 6;
			// 
			// btn_beb
			// 
			this.btn_beb.Dock = System.Windows.Forms.DockStyle.Fill;
			this.btn_beb.Location = new System.Drawing.Point(234, 0);
			this.btn_beb.Name = "btn_beb";
			this.btn_beb.Size = new System.Drawing.Size(261, 50);
			this.btn_beb.TabIndex = 10;
			this.btn_beb.Text = "BEBIDAS";
			this.btn_beb.UseVisualStyleBackColor = true;
			// 
			// btn_sob
			// 
			this.btn_sob.Dock = System.Windows.Forms.DockStyle.Right;
			this.btn_sob.Location = new System.Drawing.Point(495, 0);
			this.btn_sob.Name = "btn_sob";
			this.btn_sob.Size = new System.Drawing.Size(234, 50);
			this.btn_sob.TabIndex = 9;
			this.btn_sob.Text = "SOBREMESAS";
			this.btn_sob.UseVisualStyleBackColor = true;
			// 
			// btn_pr
			// 
			this.btn_pr.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn_pr.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btn_pr.Location = new System.Drawing.Point(0, 0);
			this.btn_pr.Name = "btn_pr";
			this.btn_pr.Size = new System.Drawing.Size(234, 50);
			this.btn_pr.TabIndex = 8;
			this.btn_pr.Text = "PRATOS";
			this.btn_pr.UseVisualStyleBackColor = true;
			// 
			// colNome
			// 
			this.colNome.DataPropertyName = "nome_pr";
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.colNome.DefaultCellStyle = dataGridViewCellStyle1;
			this.colNome.HeaderText = "Pratos";
			this.colNome.Name = "colNome";
			this.colNome.ReadOnly = true;
			// 
			// colValor
			// 
			this.colValor.DataPropertyName = "valor_pr";
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.Format = "#,##0";
			this.colValor.DefaultCellStyle = dataGridViewCellStyle2;
			this.colValor.HeaderText = "Preços";
			this.colValor.Name = "colValor";
			this.colValor.ReadOnly = true;
			this.colValor.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			// 
			// colDesc
			// 
			this.colDesc.DataPropertyName = "desc_pr";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.colDesc.DefaultCellStyle = dataGridViewCellStyle3;
			this.colDesc.HeaderText = "Descrições";
			this.colDesc.Name = "colDesc";
			this.colDesc.ReadOnly = true;
			// 
			// col_btnAdd
			// 
			this.col_btnAdd.HeaderText = "Adicionar";
			this.col_btnAdd.Name = "col_btnAdd";
			this.col_btnAdd.ReadOnly = true;
			// 
			// frm_menu
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(963, 511);
			this.Controls.Add(this.pn_btns);
			this.Controls.Add(this.pn_menu);
			this.Controls.Add(this.pn_padido);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm_menu";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Load += new System.EventHandler(this.frm_menu_Load);
			this.panel1.ResumeLayout(false);
			this.pn_padido.ResumeLayout(false);
			this.pn_menu.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgv_Menu)).EndInit();
			this.pn_btns.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
		private System.Windows.Forms.Panel pn_padido;
		private System.Windows.Forms.Panel pn_menu;
		private System.Windows.Forms.Panel pn_btns;
		private System.Windows.Forms.Button btn_beb;
		private System.Windows.Forms.Button btn_sob;
		private System.Windows.Forms.Button btn_pr;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.DataGridView dgv_Menu;
		private System.Windows.Forms.DataGridViewTextBoxColumn colNome;
		private System.Windows.Forms.DataGridViewTextBoxColumn colValor;
		private System.Windows.Forms.DataGridViewTextBoxColumn colDesc;
		private System.Windows.Forms.DataGridViewButtonColumn col_btnAdd;
	}
}