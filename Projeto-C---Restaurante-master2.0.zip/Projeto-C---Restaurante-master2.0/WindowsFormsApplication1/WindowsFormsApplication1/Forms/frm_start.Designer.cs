﻿namespace WindowsFormsApplication1
{
    partial class frm_start
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_start));
			this.btn_inicio = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.minimize = new System.Windows.Forms.Button();
			this.settings = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// btn_inicio
			// 
			this.btn_inicio.BackColor = System.Drawing.Color.Transparent;
			this.btn_inicio.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_inicio.BackgroundImage")));
			this.btn_inicio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btn_inicio.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btn_inicio.FlatAppearance.BorderSize = 0;
			this.btn_inicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
			this.btn_inicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
			this.btn_inicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_inicio.ForeColor = System.Drawing.Color.LightGray;
			this.btn_inicio.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_inicio.Location = new System.Drawing.Point(341, 179);
			this.btn_inicio.Name = "btn_inicio";
			this.btn_inicio.Size = new System.Drawing.Size(199, 180);
			this.btn_inicio.TabIndex = 1;
			this.btn_inicio.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.btn_inicio.UseVisualStyleBackColor = false;
			this.btn_inicio.Click += new System.EventHandler(this.btn_inicio_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
			this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
			this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.exit.Location = new System.Drawing.Point(855, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 4;
			this.exit.Text = "✕";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(880, 25);
			this.panel1.TabIndex = 2;
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.minimize.Location = new System.Drawing.Point(830, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 3;
			this.minimize.Text = "▁";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// settings
			// 
			this.settings.BackColor = System.Drawing.Color.Transparent;
			this.settings.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("settings.BackgroundImage")));
			this.settings.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.settings.Cursor = System.Windows.Forms.Cursors.Hand;
			this.settings.FlatAppearance.BorderSize = 0;
			this.settings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
			this.settings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
			this.settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.settings.Location = new System.Drawing.Point(832, 10);
			this.settings.Name = "settings";
			this.settings.Size = new System.Drawing.Size(40, 40);
			this.settings.TabIndex = 2;
			this.settings.UseVisualStyleBackColor = false;
			this.settings.Click += new System.EventHandler(this.settings_Click);
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.DarkRed;
			this.panel2.Controls.Add(this.settings);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel2.Location = new System.Drawing.Point(0, 25);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(880, 86);
			this.panel2.TabIndex = 3;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(290, 362);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(300, 26);
			this.label1.TabIndex = 4;
			this.label1.Text = "Faça seu pedido agora mesmo!";
			// 
			// frm_start
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(880, 550);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btn_inicio);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm_start";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "tela_inicial";
			this.Load += new System.EventHandler(this.start_Load);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_inicio;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button settings;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label1;
	}
}

