﻿namespace WindowsFormsApplication1
{
	partial class frm_removeFunc
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.minimize = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btn_remPr = new System.Windows.Forms.Button();
			this.grid_remove = new System.Windows.Forms.DataGridView();
			this.btn_back = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.grid_remove)).BeginInit();
			this.SuspendLayout();
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.minimize.Location = new System.Drawing.Point(814, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 3;
			this.minimize.Text = "▁";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
			this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
			this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.exit.Location = new System.Drawing.Point(839, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 4;
			this.exit.Text = "✕";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.btn_back);
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(864, 25);
			this.panel1.TabIndex = 3;
			// 
			// btn_remPr
			// 
			this.btn_remPr.Location = new System.Drawing.Point(370, 396);
			this.btn_remPr.Name = "btn_remPr";
			this.btn_remPr.Size = new System.Drawing.Size(125, 46);
			this.btn_remPr.TabIndex = 8;
			this.btn_remPr.Text = "Remover";
			this.btn_remPr.UseVisualStyleBackColor = true;
			this.btn_remPr.Click += new System.EventHandler(this.btn_remPr_Click);
			// 
			// grid_remove
			// 
			this.grid_remove.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.grid_remove.Location = new System.Drawing.Point(160, 69);
			this.grid_remove.Name = "grid_remove";
			this.grid_remove.Size = new System.Drawing.Size(544, 275);
			this.grid_remove.TabIndex = 9;
			// 
			// btn_back
			// 
			this.btn_back.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn_back.Location = new System.Drawing.Point(0, 0);
			this.btn_back.Name = "btn_back";
			this.btn_back.Size = new System.Drawing.Size(51, 25);
			this.btn_back.TabIndex = 10;
			this.btn_back.Text = "Back";
			this.btn_back.UseVisualStyleBackColor = true;
			this.btn_back.Click += new System.EventHandler(this.btn_back_Click_1);
			// 
			// frm_removeFunc
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(864, 511);
			this.Controls.Add(this.btn_remPr);
			this.Controls.Add(this.grid_remove);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm_removeFunc";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "frm_removeFunc";
			this.Load += new System.EventHandler(this.frm_removeFunc_Load);
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.grid_remove)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button minimize;
		private System.Windows.Forms.Button exit;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btn_remPr;
		private System.Windows.Forms.DataGridView grid_remove;
		private System.Windows.Forms.Button btn_back;
	}
}