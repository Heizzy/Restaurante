﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frm_menu : Form
    {

		DAO dao = new  DAO();
		Pedido pedido = new Pedido();

        public frm_menu()
        {
            InitializeComponent();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

		private void minimize_Click(object sender, EventArgs e)
		{
			this.WindowState = FormWindowState.Minimized;
		}

		private void frm_menu_Load(object sender, EventArgs e)
		{
			dgv_Menu.DataSource = dao.listar_pratos();
		}

		private void dgv_Menu_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.ColumnIndex == this.col_btnAdd.Index && e.RowIndex >= 0)
			{
				// pega a linha atual...
				DataGridViewRow currentRow = this.dgv_Menu.Rows[e.RowIndex];
				// mostra o form...
				pedido.addPedido(int.Parse(dgv_Menu.CurrentRow.Cells[0].Value.ToString()));
			}
		}

		private void btn_pr_Click(object sender, EventArgs e)
		{
		}

		private void btn_beb_Click(object sender, EventArgs e)
		{
		}

		private void btn_sob_Click(object sender, EventArgs e)
		{
		}
	}
}
