﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
	class Pedido
	{
		DAO dao = new DAO();

		public void addPedido(int id)
		{
			dao.addPedido(id);
		}
	}
}
