﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Pessoa
    {
        public string nome;
        public string cpf;
        public string senha;
    }
}

