﻿namespace WindowsFormsApplication1
{
    partial class frm_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.minimize = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.pn_padido = new System.Windows.Forms.Panel();
			this.pn_menu = new System.Windows.Forms.Panel();
			this.pn_btns = new System.Windows.Forms.Panel();
			this.btn_beb = new System.Windows.Forms.Button();
			this.btn_sob = new System.Windows.Forms.Button();
			this.btn_pr = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.pn_btns.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(936, 25);
			this.panel1.TabIndex = 3;
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.Location = new System.Drawing.Point(886, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 2;
			this.minimize.Text = "_";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.Location = new System.Drawing.Point(911, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 1;
			this.exit.Text = "x";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// pn_padido
			// 
			this.pn_padido.Dock = System.Windows.Forms.DockStyle.Right;
			this.pn_padido.Location = new System.Drawing.Point(702, 25);
			this.pn_padido.Name = "pn_padido";
			this.pn_padido.Size = new System.Drawing.Size(234, 486);
			this.pn_padido.TabIndex = 4;
			// 
			// pn_menu
			// 
			this.pn_menu.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pn_menu.Location = new System.Drawing.Point(0, 74);
			this.pn_menu.Name = "pn_menu";
			this.pn_menu.Size = new System.Drawing.Size(702, 437);
			this.pn_menu.TabIndex = 5;
			// 
			// pn_btns
			// 
			this.pn_btns.Controls.Add(this.btn_beb);
			this.pn_btns.Controls.Add(this.btn_sob);
			this.pn_btns.Controls.Add(this.btn_pr);
			this.pn_btns.Dock = System.Windows.Forms.DockStyle.Top;
			this.pn_btns.Location = new System.Drawing.Point(0, 25);
			this.pn_btns.Name = "pn_btns";
			this.pn_btns.Size = new System.Drawing.Size(702, 50);
			this.pn_btns.TabIndex = 6;
			// 
			// btn_beb
			// 
			this.btn_beb.Dock = System.Windows.Forms.DockStyle.Fill;
			this.btn_beb.Location = new System.Drawing.Point(234, 0);
			this.btn_beb.Name = "btn_beb";
			this.btn_beb.Size = new System.Drawing.Size(234, 50);
			this.btn_beb.TabIndex = 10;
			this.btn_beb.Text = "BEBIDAS";
			this.btn_beb.UseVisualStyleBackColor = true;
			// 
			// btn_sob
			// 
			this.btn_sob.Dock = System.Windows.Forms.DockStyle.Right;
			this.btn_sob.Location = new System.Drawing.Point(468, 0);
			this.btn_sob.Name = "btn_sob";
			this.btn_sob.Size = new System.Drawing.Size(234, 50);
			this.btn_sob.TabIndex = 9;
			this.btn_sob.Text = "SOBREMESAS";
			this.btn_sob.UseVisualStyleBackColor = true;
			// 
			// btn_pr
			// 
			this.btn_pr.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn_pr.Location = new System.Drawing.Point(0, 0);
			this.btn_pr.Name = "btn_pr";
			this.btn_pr.Size = new System.Drawing.Size(234, 50);
			this.btn_pr.TabIndex = 8;
			this.btn_pr.Text = "PRATOS";
			this.btn_pr.UseVisualStyleBackColor = true;
			// 
			// frm_menu
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(936, 511);
			this.Controls.Add(this.pn_btns);
			this.Controls.Add(this.pn_menu);
			this.Controls.Add(this.pn_padido);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm_menu";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.panel1.ResumeLayout(false);
			this.pn_btns.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
		private System.Windows.Forms.Panel pn_padido;
		private System.Windows.Forms.Panel pn_menu;
		private System.Windows.Forms.Panel pn_btns;
		private System.Windows.Forms.Button btn_beb;
		private System.Windows.Forms.Button btn_sob;
		private System.Windows.Forms.Button btn_pr;
	}
}