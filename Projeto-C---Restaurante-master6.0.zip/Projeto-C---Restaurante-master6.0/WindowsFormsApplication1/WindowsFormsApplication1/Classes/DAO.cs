﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    class DAO
    {
        public MySqlConnection mConn;

        public MySqlDataAdapter mAdapter;
        public String sql;
        public DataSet mDataSet;
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dr;
        public bool verify = false;
		public float valortotal;

		public DAO()
        {
            mConn = new MySqlConnection("server=localhost; database=restaurante; uid=root; password=vertrigo; SslMode=none");
            try
            {
                //abre a conexao
                mConn.Open();
            }

            catch (System.Exception e)
            {
                Console.WriteLine(e.Message.ToString());
            }
        }//fim DAO


		public bool vry_cliente(string cpf, string nome, string mesa)
		//verifica se o cliente já é cadastrado
		{
			verify = false;
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "Select * from cliente where cpf_cliente = @cpf and nome_cliente = @nome";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@nome", nome);
				MySqlDataReader dr = cmd.ExecuteReader();
				if (dr.HasRows)
				{
					verify = true;
                    dr.Close();
				}
                else
                {
                    dr.Close();
                }

			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
			return verify;
          
		}

		public void cad_cliente(string cpf, string nome, int pagamento, string mesa)
        //cadastra o cliente
        {
            if (mConn.State == ConnectionState.Open)
            { }
            else
            {
                mConn.Open();
            }
            try
            {
                sql = "insert into cliente(cpf_cliente, nome_cliente, cod_pagamento, mesa_cliente) values (@cpf,@nome, @pagamento, @mesa)";
                MySqlCommand cmd = new MySqlCommand(sql, mConn);
                cmd.Parameters.AddWithValue("@nome", nome);
                cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@pagamento", pagamento);
				cmd.Parameters.AddWithValue("@mesa", mesa);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mConn.Close();
            }
        }

		public bool Login_funcionario(string cpf, string senha)
		// checa o login dos funcionários
		{
			verify = false;
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "Select * from funcionario where cpf_func = @cpf and senha_func = @senha";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@senha", senha);
				this.dr = cmd.ExecuteReader();
				if (dr.HasRows)
				{
                    dr.Close();
					verify = true;
				}
                else
                {
                    dr.Close();
                }
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
			return verify;
		}

		public void cad_funcionario(string cpf, string nome, int cargo, string senha)
        // cadastra o funcionário
        {
            if (mConn.State == ConnectionState.Open)
            { }
            else
            {
                mConn.Open();
            }
            try
            {
                sql = "insert into funcionario(cod_func, cpf_func, nome_func, cod_cargo, senha_func) values (null, @cpf,@nome,@cargo, @senha)";
                MySqlCommand cmd = new MySqlCommand(sql, mConn);
                cmd.Parameters.AddWithValue("@nome", nome);
                cmd.Parameters.AddWithValue("@cpf", cpf);
                cmd.Parameters.AddWithValue("@cargo", cargo);
                cmd.Parameters.AddWithValue("@senha", senha);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mConn.Close();
            }
        }

		public DataTable listar_pratos()
		{
			try
			{
				sql = "SELECT * FROM pratos";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public DataTable listar_comidas()
		{
			try
			{
				sql = "SELECT * FROM pratos where cod_tp = 1";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public DataTable listar_bebidas()
		{
			try
			{
				sql = "SELECT * FROM pratos where cod_tp = 2";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public DataTable listar_sobremesas()
		{
			try
			{
				sql = "SELECT * FROM pratos where cod_tp = 3";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public DataTable listar_func()
		{
			try
			{
				sql = "SELECT * FROM funcionario";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public DataTable listar_pedido(string cpf)
		{
			try
			{
				sql = "SELECT * FROM pedidos where cpf_cliente = @cpf";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public DataTable listar_todosped()
		{
			try
			{
				sql = "SELECT * FROM pedidos";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public DataTable listar_clientes()
		{
			try
			{
				sql = "SELECT DISTINCT cpf_cliente, mesa_cliente, status_pedido FROM pedidos";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public DataTable listar_pagamento(string cpf)
		{
			try
			{
				sql = "SELECT cpf_cliente, mesa_cliente, cod_pagamento FROM cliente where cpf_cliente = @cpf";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
				return dt;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public void remover_func(int id)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				var result = MessageBox.Show("Deseja remover este funcionário?", "Remover Prato", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (result == DialogResult.Yes)
				{
					sql = "delete from funcionario WHERE cod_func = @id ";
					MySqlCommand cmd = new MySqlCommand(sql, mConn);
					cmd.Parameters.AddWithValue("@id", id);
					cmd.ExecuteNonQuery();
					MessageBox.Show("Funcionário removido com sucesso!");
				}
				else
				{
					MessageBox.Show("Funcionário não removido", "Remoção cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				//mConn.Close();
			}
		}

		public void remover_prato(int id)
        {
            if (mConn.State == ConnectionState.Open)
            { }
            else
            {
                mConn.Open();
            }
            try
            {
                var result = MessageBox.Show("Deseja remover este prato", "Remover Prato", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    sql = "delete from pratos WHERE cod_pr = @id";
                    MySqlCommand cmd = new MySqlCommand(sql, mConn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Prato removido com sucesso!");
                }
                else
                {
                    MessageBox.Show("Prato não removido", "Remoção cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                //mConn.Close();
            }
        }

		public void menu_pratos()
		{
			try
			{
				sql = "SELECT * FROM pratos";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				mAdapter = new MySqlDataAdapter();
				mAdapter.SelectCommand = cmd;
				DataTable dt = new DataTable();
				mAdapter.Fill(dt);
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}

		public void Add_Prato(string nome, decimal valor, int tipo, string descricao)
		//adicoina um novo prato ao restaurante
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "insert into pratos(nome_pr, valor_pr, cod_tp, desc_pr) values (@nome,@valor,@tipo, @descricao)";

				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@nome", nome);
				cmd.Parameters.AddWithValue("@valor", valor);
				cmd.Parameters.AddWithValue("@tipo", tipo);
				cmd.Parameters.AddWithValue("@descricao", descricao);
				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

		public void addPedido(string mesa, string cpf, int codPr, string nome, float preco, string status)
		//inicia um novo pedido
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
                sql = "select * from pedidos where cod_pr = @codPr and cpf_cliente =  @cpf";
                MySqlCommand cmd = new MySqlCommand(sql, mConn);
                cmd.Parameters.AddWithValue("@cpf", cpf);
                cmd.Parameters.AddWithValue("@codPr", codPr);
                MySqlDataReader rd = cmd.ExecuteReader();
                rd.Read();
                if (rd.HasRows)
                {
                    rd.Close();
                    sql = "update pedidos set quant_pr = quant_pr+1 WHERE cpf_cliente = @cpf and cod_pr = @codPr";
					cmd = new MySqlCommand(sql,mConn);
                    cmd.Parameters.AddWithValue("@cpf", cpf);
                    cmd.Parameters.AddWithValue("@codPr", codPr);
					cmd.Parameters.AddWithValue("@preco", preco);
					cmd.ExecuteNonQuery();

					sql = "update pedidos set valor_pr = valor_pr+@preco WHERE cpf_cliente = @cpf and cod_pr = @codPr";
					cmd = new MySqlCommand(sql, mConn);
					cmd.Parameters.AddWithValue("@cpf", cpf);
					cmd.Parameters.AddWithValue("@codPr", codPr);
					cmd.Parameters.AddWithValue("@preco", preco);
					cmd.ExecuteNonQuery();
				}
                else
                {
                    rd.Close();
                    sql = "insert into pedidos(mesa_cliente, cpf_cliente, cod_pr, nome_pr, valor_pr, quant_pr , status_pedido) values (@mesa, @cpf, @codPr, @nome, @preco, 1, @status)";
                    cmd = new MySqlCommand(sql, mConn);
					cmd.Parameters.AddWithValue("@mesa", mesa);
					cmd.Parameters.AddWithValue("@cpf", cpf);
                    cmd.Parameters.AddWithValue("@codPr", codPr);
					cmd.Parameters.AddWithValue("@nome", nome);
					cmd.Parameters.AddWithValue("@preco", preco);
					cmd.Parameters.AddWithValue("@status", status);

					cmd.ExecuteNonQuery();
                }
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

		public void remQuant(string cpf, int codPr, float preco)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update pedidos set quant_pr = quant_pr-1 WHERE cpf_cliente = @cpf and cod_pr = @codPr";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@codPr", codPr);
                cmd.ExecuteNonQuery();

				sql = "update pedidos set valor_pr = valor_pr-@preco WHERE cpf_cliente = @cpf and cod_pr = @codPr";
				cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@codPr", codPr);
				cmd.Parameters.AddWithValue("@preco", preco);
				cmd.ExecuteNonQuery();

				sql = "select * from pedidos where cod_pr = @codPr and cpf_cliente =  @cpf and quant_pr = 0";
                cmd = new MySqlCommand(sql, mConn);
                cmd.Parameters.AddWithValue("@cpf", cpf);
                cmd.Parameters.AddWithValue("@codPr", codPr);
                MySqlDataReader rd = cmd.ExecuteReader();
                rd.Read();
                if (rd.HasRows)
                {
                    rd.Close();
                    sql = "delete from pedidos where cod_pr = @codPr and cpf_cliente =  @cpf";
                    cmd = new MySqlCommand(sql, mConn);
                    cmd.Parameters.AddWithValue("@cpf", cpf);
                    cmd.Parameters.AddWithValue("@codPr", codPr);
                    cmd.ExecuteNonQuery();
                }
            }
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

        public void finality(string cpf)
        {
            if (mConn.State == ConnectionState.Open)
            { }
            else
            {
                mConn.Open();
            }
            try
            {
                sql = "update pedidos set status_pedido ='Em processamento' WHERE cpf_cliente = @cpf";
                MySqlCommand cmd = new MySqlCommand(sql, mConn);
                cmd.Parameters.AddWithValue("@cpf", cpf);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mConn.Close();
            }
        }
    

		public void clear(string cpf)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "delete from pedidos where cpf_cliente = @cpf";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);

				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

        public void verifcarCargo(string cpf,Funcionario F)
        {

            if (mConn.State == ConnectionState.Open)
            { }
            else
            {
                mConn.Open();
            }
            try
            {
                sql = "select cod_cargo from funcionario where cpf_func = @cpf and cod_cargo = 1";
                MySqlCommand cmd = new MySqlCommand(sql,mConn);
                cmd.Parameters.AddWithValue("@cpf",cpf);
                MySqlDataReader rd = cmd.ExecuteReader();
                rd.Read();
                if (rd.HasRows)
                {
                    rd.Close();
                    F.cargo = 1;

                }
                else
                {
                    rd.Close();
                    sql = "select cod_cargo from funcionario where cpf_func = @cpf and cod_cargo = 2";
                    cmd = new MySqlCommand(sql, mConn);
                    cmd.Parameters.AddWithValue("@cpf", cpf);
                    rd = cmd.ExecuteReader();
                    rd.Read();
                    if (rd.HasRows)
                    {
                        rd.Close();
                        F.cargo = 2;
                    }
                    else
                    {
                        rd.Close();
                        sql = "select cod_cargo from funcionario where cpf_func = @cpf and cod_cargo = 3";
                        cmd = new MySqlCommand(sql, mConn);
                        cmd.Parameters.AddWithValue("@cpf", cpf);
                        rd = cmd.ExecuteReader();
                        rd.Read();
                        if (rd.HasRows)
                        {
                            rd.Close();
                            F.cargo = 3;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                mConn.Close();
            }
        }

		public float total(string cpf)
		{
			/*if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "select sum(valor_pr) from pedidos where cpf_cliente = @cpf";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
			    dr = cmd.ExecuteReader();
				dr.Read();
				if (dr.HasRows)
				{

					valortotal = float.Parse(dr[0].ToString());
					dr.Close();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}*/
			return valortotal;

		}

		public void statuspreparo(string cpf, int codPr)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update pedidos set status_pedido = 'Sendo preparado' where cpf_cliente = @cpf and cod_pr = @codPr";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@codPr", codPr);

				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

		public void dinheiro(string cpf)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update cliente set cod_pagamento = 1 where cpf_cliente = @cpf";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

		public void credito(string cpf)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update cliente set cod_pagamento = 2 where cpf_cliente = @cpf";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

		public void debito(string cpf)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update cliente set cod_pagamento = 3 where cpf_cliente = @cpf";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

		public void statussaindo(string cpf, int codPr)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update pedidos set status_pedido = 'Saindo' where cpf_cliente = @cpf and cod_pr = @codPr";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@codPr", codPr);

				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

		public void pago(string cpf)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update cliente set cod_pagamento = 5 where cpf_cliente = @cpf";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);

				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}

		public void statusentregue(string cpf, int codPr)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update pedidos set status_pedido = 'Entregue' where cpf_cliente = @cpf and cod_pr = @codPr";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@codPr", codPr);

				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}



		public void statuspronto(string cpf, int codPr)
		{
			if (mConn.State == ConnectionState.Open)
			{ }
			else
			{
				mConn.Open();
			}
			try
			{
				sql = "update pedidos set status_pedido = 'Pronto' where cpf_cliente = @cpf and cod_pr = @codPr";
				MySqlCommand cmd = new MySqlCommand(sql, mConn);
				cmd.Parameters.AddWithValue("@cpf", cpf);
				cmd.Parameters.AddWithValue("@codPr", codPr);

				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				mConn.Close();
			}
		}
	}
}