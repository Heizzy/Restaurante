﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
	class Pedido
	{
		DAO dao = new DAO();
		public bool verify;
		public float valortotal;

		public void listpedido(string mesa, string cpf, int codPr, string nome, float preco, string status)
		{
			dao.addPedido(mesa, cpf, codPr, nome, preco, status);
		}

		public void remQuant(string cpf, int codPr, float preco)
		{
			dao.remQuant(cpf, codPr, preco);
		}

		public float total(string cpf)
		{

			dao.total(cpf);

			return valortotal;
		}

        public void finality(string cpf)
        {
            dao.finality(cpf);
        }
	}
}
