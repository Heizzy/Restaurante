﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
	public partial class frm_removeFunc : Form
	{
		public frm_removeFunc()
		{
			InitializeComponent();
		}

		DAO dao = new DAO();

		private void exit_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void minimize_Click(object sender, EventArgs e)
		{
			this.WindowState = FormWindowState.Minimized;
		}

		private void btn_back_Click_1(object sender, EventArgs e)
		{
			frm_admLogado back = new frm_admLogado();
			back.ShowDialog();
		}

		private void frm_removeFunc_Load(object sender, EventArgs e)
		{
			grid_remove.DataSource = dao.listar_func();
		}

		private void btn_remPr_Click(object sender, EventArgs e)
		{
			int rowIndex = grid_remove.CurrentCell.RowIndex;
			dao.remover_func(int.Parse(grid_remove.CurrentRow.Cells[0].Value.ToString()));
			grid_remove.DataSource = dao.listar_func();
		}
	}
}
