﻿namespace WindowsFormsApplication1
{
    partial class frm_fechar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_fechar));
			this.minimize = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.lbl_total = new System.Windows.Forms.Label();
			this.btn_dinheiro = new System.Windows.Forms.Button();
			this.btn_cartao = new System.Windows.Forms.Button();
			this.btn_de = new System.Windows.Forms.Button();
			this.btn_cre = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.FlatAppearance.BorderSize = 0;
			this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.minimize.Location = new System.Drawing.Point(814, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 3;
			this.minimize.Text = "▁";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.FlatAppearance.BorderSize = 0;
			this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
			this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
			this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.exit.Location = new System.Drawing.Point(839, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 4;
			this.exit.Text = "✕";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(864, 25);
			this.panel1.TabIndex = 4;
			// 
			// lbl_total
			// 
			this.lbl_total.AutoSize = true;
			this.lbl_total.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_total.Location = new System.Drawing.Point(413, 144);
			this.lbl_total.Name = "lbl_total";
			this.lbl_total.Size = new System.Drawing.Size(66, 26);
			this.lbl_total.TabIndex = 5;
			this.lbl_total.Text = "Preço";
			// 
			// btn_dinheiro
			// 
			this.btn_dinheiro.BackColor = System.Drawing.Color.Transparent;
			this.btn_dinheiro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_dinheiro.BackgroundImage")));
			this.btn_dinheiro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.btn_dinheiro.FlatAppearance.BorderSize = 0;
			this.btn_dinheiro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_dinheiro.Location = new System.Drawing.Point(342, 189);
			this.btn_dinheiro.Name = "btn_dinheiro";
			this.btn_dinheiro.Size = new System.Drawing.Size(196, 51);
			this.btn_dinheiro.TabIndex = 6;
			this.btn_dinheiro.Text = "Em dinheiro";
			this.btn_dinheiro.UseVisualStyleBackColor = false;
			this.btn_dinheiro.Click += new System.EventHandler(this.btn_dinheiro_Click);
			// 
			// btn_cartao
			// 
			this.btn_cartao.BackColor = System.Drawing.Color.Transparent;
			this.btn_cartao.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cartao.BackgroundImage")));
			this.btn_cartao.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.btn_cartao.FlatAppearance.BorderSize = 0;
			this.btn_cartao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_cartao.Location = new System.Drawing.Point(342, 280);
			this.btn_cartao.Name = "btn_cartao";
			this.btn_cartao.Size = new System.Drawing.Size(196, 51);
			this.btn_cartao.TabIndex = 7;
			this.btn_cartao.Text = "No cartão";
			this.btn_cartao.UseVisualStyleBackColor = false;
			this.btn_cartao.Click += new System.EventHandler(this.btn_cartao_Click);
			// 
			// btn_de
			// 
			this.btn_de.BackColor = System.Drawing.Color.Transparent;
			this.btn_de.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_de.BackgroundImage")));
			this.btn_de.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.btn_de.FlatAppearance.BorderSize = 0;
			this.btn_de.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_de.Location = new System.Drawing.Point(342, 423);
			this.btn_de.Name = "btn_de";
			this.btn_de.Size = new System.Drawing.Size(196, 51);
			this.btn_de.TabIndex = 8;
			this.btn_de.Text = "Débito";
			this.btn_de.UseVisualStyleBackColor = false;
			this.btn_de.Click += new System.EventHandler(this.btn_de_Click);
			// 
			// btn_cre
			// 
			this.btn_cre.BackColor = System.Drawing.Color.Transparent;
			this.btn_cre.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cre.BackgroundImage")));
			this.btn_cre.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.btn_cre.FlatAppearance.BorderSize = 0;
			this.btn_cre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_cre.Location = new System.Drawing.Point(342, 366);
			this.btn_cre.Name = "btn_cre";
			this.btn_cre.Size = new System.Drawing.Size(196, 51);
			this.btn_cre.TabIndex = 9;
			this.btn_cre.Text = "Crédito";
			this.btn_cre.UseVisualStyleBackColor = false;
			this.btn_cre.Click += new System.EventHandler(this.btn_cre_Click);
			// 
			// panel2
			// 
			this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
			this.panel2.Controls.Add(this.btn_cre);
			this.panel2.Controls.Add(this.btn_dinheiro);
			this.panel2.Controls.Add(this.btn_de);
			this.panel2.Controls.Add(this.lbl_total);
			this.panel2.Controls.Add(this.btn_cartao);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(0, 25);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(864, 486);
			this.panel2.TabIndex = 10;
			this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
			// 
			// frm_fechar
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(864, 511);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm_fechar";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "frm_fechar";
			this.Load += new System.EventHandler(this.frm_fechar_Load);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.Button btn_dinheiro;
        private System.Windows.Forms.Button btn_cartao;
        private System.Windows.Forms.Button btn_de;
        private System.Windows.Forms.Button btn_cre;
		private System.Windows.Forms.Panel panel2;
	}
}