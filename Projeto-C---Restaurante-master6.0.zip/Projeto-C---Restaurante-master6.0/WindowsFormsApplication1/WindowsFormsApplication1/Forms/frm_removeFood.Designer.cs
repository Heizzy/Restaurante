﻿namespace WindowsFormsApplication1
{
    partial class frm_removeFood
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			this.minimize = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btn_back = new System.Windows.Forms.Button();
			this.grid_remove = new System.Windows.Forms.DataGridView();
			this.btn_remPr = new System.Windows.Forms.Button();
			this.Cod = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colValor = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colTipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.grid_remove)).BeginInit();
			this.SuspendLayout();
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.Location = new System.Drawing.Point(830, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 4;
			this.minimize.Text = "_";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.Location = new System.Drawing.Point(855, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 3;
			this.exit.Text = "x";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.btn_back);
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(880, 25);
			this.panel1.TabIndex = 5;
			// 
			// btn_back
			// 
			this.btn_back.Location = new System.Drawing.Point(3, 1);
			this.btn_back.Name = "btn_back";
			this.btn_back.Size = new System.Drawing.Size(51, 23);
			this.btn_back.TabIndex = 9;
			this.btn_back.Text = "Back";
			this.btn_back.UseVisualStyleBackColor = true;
			this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
			// 
			// grid_remove
			// 
			this.grid_remove.AllowUserToAddRows = false;
			this.grid_remove.AllowUserToDeleteRows = false;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gray;
			dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
			this.grid_remove.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
			this.grid_remove.BackgroundColor = System.Drawing.Color.White;
			this.grid_remove.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.grid_remove.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Cod,
            this.colNome,
            this.colValor,
            this.colTipo,
            this.colDesc});
			this.grid_remove.Dock = System.Windows.Forms.DockStyle.Top;
			this.grid_remove.Location = new System.Drawing.Point(0, 25);
			this.grid_remove.MultiSelect = false;
			this.grid_remove.Name = "grid_remove";
			this.grid_remove.ReadOnly = true;
			this.grid_remove.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.grid_remove.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.grid_remove.Size = new System.Drawing.Size(880, 410);
			this.grid_remove.TabIndex = 7;
			// 
			// btn_remPr
			// 
			this.btn_remPr.Location = new System.Drawing.Point(378, 453);
			this.btn_remPr.Name = "btn_remPr";
			this.btn_remPr.Size = new System.Drawing.Size(125, 46);
			this.btn_remPr.TabIndex = 0;
			this.btn_remPr.Text = "Remover";
			this.btn_remPr.UseVisualStyleBackColor = true;
			this.btn_remPr.Click += new System.EventHandler(this.btn_remPr_Click);
			// 
			// Cod
			// 
			this.Cod.DataPropertyName = "cod_pr";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle2.Format = "#,##0";
			this.Cod.DefaultCellStyle = dataGridViewCellStyle2;
			this.Cod.HeaderText = "Código";
			this.Cod.Name = "Cod";
			this.Cod.ReadOnly = true;
			this.Cod.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			// 
			// colNome
			// 
			this.colNome.DataPropertyName = "nome_pr";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.colNome.DefaultCellStyle = dataGridViewCellStyle3;
			this.colNome.HeaderText = "Nome";
			this.colNome.Name = "colNome";
			this.colNome.ReadOnly = true;
			this.colNome.Width = 172;
			// 
			// colValor
			// 
			this.colValor.DataPropertyName = "valor_pr";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.colValor.DefaultCellStyle = dataGridViewCellStyle4;
			this.colValor.HeaderText = "Preço";
			this.colValor.Name = "colValor";
			this.colValor.ReadOnly = true;
			this.colValor.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.colValor.Width = 172;
			// 
			// colTipo
			// 
			this.colTipo.DataPropertyName = "cod_tp";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.colTipo.DefaultCellStyle = dataGridViewCellStyle5;
			this.colTipo.HeaderText = "Tipo de prato";
			this.colTipo.Name = "colTipo";
			this.colTipo.ReadOnly = true;
			this.colTipo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.colTipo.Width = 177;
			// 
			// colDesc
			// 
			this.colDesc.DataPropertyName = "desc_pr";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.colDesc.DefaultCellStyle = dataGridViewCellStyle6;
			this.colDesc.HeaderText = "Descrição";
			this.colDesc.Name = "colDesc";
			this.colDesc.ReadOnly = true;
			this.colDesc.Width = 215;
			// 
			// frm_removeFood
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.DarkRed;
			this.ClientSize = new System.Drawing.Size(880, 550);
			this.Controls.Add(this.btn_remPr);
			this.Controls.Add(this.grid_remove);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.HelpButton = true;
			this.MinimizeBox = false;
			this.Name = "frm_removeFood";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "frm_removeFood";
			this.Load += new System.EventHandler(this.frm_removeFood_Load);
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.grid_remove)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView grid_remove;
        private System.Windows.Forms.Button btn_remPr;
        private System.Windows.Forms.Button btn_back;
		private System.Windows.Forms.DataGridViewTextBoxColumn Cod;
		private System.Windows.Forms.DataGridViewTextBoxColumn colNome;
		private System.Windows.Forms.DataGridViewTextBoxColumn colValor;
		private System.Windows.Forms.DataGridViewTextBoxColumn colTipo;
		private System.Windows.Forms.DataGridViewTextBoxColumn colDesc;
	}
}