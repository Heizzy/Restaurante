﻿namespace WindowsFormsApplication1
{
	partial class frm_garLogado
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.minimize = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btn_back = new System.Windows.Forms.Button();
			this.dgv_clientes = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.btn_verPedido = new System.Windows.Forms.Button();
			this.btn_saindo = new System.Windows.Forms.Button();
			this.btn_entregue = new System.Windows.Forms.Button();
			this.dgv_pedidos = new System.Windows.Forms.DataGridView();
			this.col_cpf = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.col_codPr = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.col_nomepr = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.col_status = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.btn_atualizar = new System.Windows.Forms.Button();
			this.dgv_pagamento = new System.Windows.Forms.DataGridView();
			this.btn_fechar = new System.Windows.Forms.Button();
			this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgv_clientes)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgv_pedidos)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgv_pagamento)).BeginInit();
			this.SuspendLayout();
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.Location = new System.Drawing.Point(1086, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 6;
			this.minimize.Text = "_";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.Location = new System.Drawing.Point(1111, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 7;
			this.exit.Text = "x";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1136, 25);
			this.panel1.TabIndex = 6;
			// 
			// btn_back
			// 
			this.btn_back.Location = new System.Drawing.Point(3, 3);
			this.btn_back.Name = "btn_back";
			this.btn_back.Size = new System.Drawing.Size(51, 23);
			this.btn_back.TabIndex = 9;
			this.btn_back.Text = "Back";
			this.btn_back.UseVisualStyleBackColor = true;
			// 
			// dgv_clientes
			// 
			this.dgv_clientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_clientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
			this.dgv_clientes.Location = new System.Drawing.Point(18, 96);
			this.dgv_clientes.Name = "dgv_clientes";
			this.dgv_clientes.Size = new System.Drawing.Size(343, 352);
			this.dgv_clientes.TabIndex = 11;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this.dataGridViewTextBoxColumn1.DataPropertyName = "mesa_cliente";
			this.dataGridViewTextBoxColumn1.HeaderText = "Mesa";
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			// 
			// dataGridViewTextBoxColumn2
			// 
			this.dataGridViewTextBoxColumn2.DataPropertyName = "cpf_cliente";
			this.dataGridViewTextBoxColumn2.HeaderText = "Nome";
			this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			// 
			// dataGridViewTextBoxColumn3
			// 
			this.dataGridViewTextBoxColumn3.DataPropertyName = "status_pedido";
			this.dataGridViewTextBoxColumn3.HeaderText = "Andamento";
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			// 
			// btn_verPedido
			// 
			this.btn_verPedido.Location = new System.Drawing.Point(18, 485);
			this.btn_verPedido.Name = "btn_verPedido";
			this.btn_verPedido.Size = new System.Drawing.Size(130, 23);
			this.btn_verPedido.TabIndex = 12;
			this.btn_verPedido.Text = "Ver pedidos do cliente";
			this.btn_verPedido.UseVisualStyleBackColor = true;
			this.btn_verPedido.Click += new System.EventHandler(this.btn_verPedido_Click);
			// 
			// btn_saindo
			// 
			this.btn_saindo.Location = new System.Drawing.Point(768, 485);
			this.btn_saindo.Name = "btn_saindo";
			this.btn_saindo.Size = new System.Drawing.Size(130, 23);
			this.btn_saindo.TabIndex = 13;
			this.btn_saindo.Text = "Atualizar para Saindo";
			this.btn_saindo.UseVisualStyleBackColor = true;
			this.btn_saindo.Click += new System.EventHandler(this.btn_saindo_Click);
			// 
			// btn_entregue
			// 
			this.btn_entregue.Location = new System.Drawing.Point(981, 485);
			this.btn_entregue.Name = "btn_entregue";
			this.btn_entregue.Size = new System.Drawing.Size(130, 23);
			this.btn_entregue.TabIndex = 14;
			this.btn_entregue.Text = "atualizar para entregue";
			this.btn_entregue.UseVisualStyleBackColor = true;
			this.btn_entregue.Click += new System.EventHandler(this.btn_entregue_Click);
			// 
			// dgv_pedidos
			// 
			this.dgv_pedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_pedidos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_cpf,
            this.col_codPr,
            this.col_nomepr,
            this.col_status});
			this.dgv_pedidos.Location = new System.Drawing.Point(768, 96);
			this.dgv_pedidos.Name = "dgv_pedidos";
			this.dgv_pedidos.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dgv_pedidos.Size = new System.Drawing.Size(343, 352);
			this.dgv_pedidos.TabIndex = 10;
			// 
			// col_cpf
			// 
			this.col_cpf.DataPropertyName = "cpf_cliente";
			this.col_cpf.HeaderText = "cpf";
			this.col_cpf.Name = "col_cpf";
			this.col_cpf.Visible = false;
			// 
			// col_codPr
			// 
			this.col_codPr.DataPropertyName = "cod_pr";
			this.col_codPr.HeaderText = "codPr";
			this.col_codPr.Name = "col_codPr";
			this.col_codPr.Visible = false;
			// 
			// col_nomepr
			// 
			this.col_nomepr.DataPropertyName = "nome_pr";
			this.col_nomepr.HeaderText = "Pratos";
			this.col_nomepr.Name = "col_nomepr";
			this.col_nomepr.Width = 200;
			// 
			// col_status
			// 
			this.col_status.DataPropertyName = "status_pedido";
			this.col_status.HeaderText = "Status";
			this.col_status.Name = "col_status";
			this.col_status.Width = 200;
			// 
			// btn_atualizar
			// 
			this.btn_atualizar.Location = new System.Drawing.Point(231, 485);
			this.btn_atualizar.Name = "btn_atualizar";
			this.btn_atualizar.Size = new System.Drawing.Size(130, 23);
			this.btn_atualizar.TabIndex = 15;
			this.btn_atualizar.Text = "Atualizar dados";
			this.btn_atualizar.UseVisualStyleBackColor = true;
			this.btn_atualizar.Click += new System.EventHandler(this.btn_atualizar_Click);
			// 
			// dgv_pagamento
			// 
			this.dgv_pagamento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgv_pagamento.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
			this.dgv_pagamento.Location = new System.Drawing.Point(392, 96);
			this.dgv_pagamento.Name = "dgv_pagamento";
			this.dgv_pagamento.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dgv_pagamento.Size = new System.Drawing.Size(343, 352);
			this.dgv_pagamento.TabIndex = 16;
			// 
			// btn_fechar
			// 
			this.btn_fechar.Location = new System.Drawing.Point(516, 485);
			this.btn_fechar.Name = "btn_fechar";
			this.btn_fechar.Size = new System.Drawing.Size(94, 23);
			this.btn_fechar.TabIndex = 17;
			this.btn_fechar.Text = "Fechar conta";
			this.btn_fechar.UseVisualStyleBackColor = true;
			this.btn_fechar.Click += new System.EventHandler(this.btn_fechar_Click);
			// 
			// dataGridViewTextBoxColumn4
			// 
			this.dataGridViewTextBoxColumn4.DataPropertyName = "mesa_cliente";
			this.dataGridViewTextBoxColumn4.HeaderText = "Mesa";
			this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			// 
			// dataGridViewTextBoxColumn5
			// 
			this.dataGridViewTextBoxColumn5.DataPropertyName = "cpf_cliente";
			this.dataGridViewTextBoxColumn5.HeaderText = "CPF";
			this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
			// 
			// dataGridViewTextBoxColumn6
			// 
			this.dataGridViewTextBoxColumn6.DataPropertyName = "cod_pagamento";
			this.dataGridViewTextBoxColumn6.HeaderText = "Pagamento";
			this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			// 
			// frm_garLogado
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1136, 550);
			this.Controls.Add(this.btn_fechar);
			this.Controls.Add(this.dgv_pagamento);
			this.Controls.Add(this.btn_atualizar);
			this.Controls.Add(this.btn_entregue);
			this.Controls.Add(this.btn_saindo);
			this.Controls.Add(this.btn_verPedido);
			this.Controls.Add(this.dgv_clientes);
			this.Controls.Add(this.dgv_pedidos);
			this.Controls.Add(this.btn_back);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm_garLogado";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "frm_garLogado";
			this.Load += new System.EventHandler(this.frm_garLogado_Load);
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgv_clientes)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgv_pedidos)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgv_pagamento)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button minimize;
		private System.Windows.Forms.Button exit;
		private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_back;
		private System.Windows.Forms.DataGridView dgv_clientes;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.Button btn_verPedido;
		private System.Windows.Forms.Button btn_saindo;
		private System.Windows.Forms.Button btn_entregue;
		private System.Windows.Forms.DataGridView dgv_pedidos;
		private System.Windows.Forms.DataGridViewTextBoxColumn col_cpf;
		private System.Windows.Forms.DataGridViewTextBoxColumn col_codPr;
		private System.Windows.Forms.DataGridViewTextBoxColumn col_nomepr;
		private System.Windows.Forms.DataGridViewTextBoxColumn col_status;
		private System.Windows.Forms.Button btn_atualizar;
		private System.Windows.Forms.DataGridView dgv_pagamento;
		private System.Windows.Forms.Button btn_fechar;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
	}
}