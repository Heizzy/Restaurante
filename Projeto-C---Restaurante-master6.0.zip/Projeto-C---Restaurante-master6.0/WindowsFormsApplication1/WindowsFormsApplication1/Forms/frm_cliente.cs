﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    public partial class frm_cliente : Form
    {
        Cliente cliente = new Cliente();

        public frm_cliente()
        {
            InitializeComponent();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btn_nextn_Click(object sender, EventArgs e)
        {
            cliente.vrycliente(txt_name.Text, txtcpf.Text);

			if (cliente.verify)
			{
				MessageBox.Show("Bem vindo de volta!");
			}
			else
			{
				cliente.cadcliente(txt_name.Text, txtcpf.Text);
			}

			this.Hide();
			frm_menu menu = new frm_menu(txtcpf.Text);
			menu.Closed += (s, args) => this.Close();
			menu.Show();
		}

		private void btn_back_Click(object sender, EventArgs e)
		{
			this.Hide();
			frm_start back = new frm_start();
			back.Closed += (s, args) => this.Close();
			back.Show();
		}

		private void txt_nome_TextChanged(object sender, EventArgs e)
        {
        }

        private void nome_Load(object sender, EventArgs e)
        {
        }
    }
}