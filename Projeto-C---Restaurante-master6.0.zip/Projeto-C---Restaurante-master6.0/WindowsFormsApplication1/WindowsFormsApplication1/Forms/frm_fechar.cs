﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frm_fechar : Form
    {
		DAO dao = new DAO();
		string cpf;

        public frm_fechar(string cpf)
        {
            InitializeComponent();
			this.cpf = cpf;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void frm_fechar_Load(object sender, EventArgs e)
        {
            btn_cre.Visible = false;
            btn_de.Visible = false;
        }

        private void btn_cartao_Click(object sender, EventArgs e)
        {
            btn_cre.Visible = true;
            btn_de.Visible = true;
        }

		private void btn_dinheiro_Click(object sender, EventArgs e)
		{
			dao.dinheiro(cpf);
		}

		private void btn_cre_Click(object sender, EventArgs e)
		{
			dao.credito(cpf);
		}

		private void btn_de_Click(object sender, EventArgs e)
		{
			dao.debito(cpf);
		}

		private void panel2_Paint(object sender, PaintEventArgs e)
		{

		}
	}
}