﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
	public partial class frm_garLogado : Form
	{

		DAO dao = new DAO();

		public frm_garLogado()
		{
			InitializeComponent();
			dgv_pedidos.AutoGenerateColumns = false;
			dgv_clientes.AutoGenerateColumns = false;
		}

		private void exit_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void minimize_Click(object sender, EventArgs e)
		{
			this.WindowState = FormWindowState.Minimized;
		}

		private void frm_garLogado_Load(object sender, EventArgs e)
		{
			dgv_clientes.DataSource = dao.listar_clientes();
			dgv_pagamento.DataSource = dao.listar_pagamento(dgv_clientes.CurrentRow.Cells[1].Value.ToString());
		}

		private void btn_verPedido_Click(object sender, EventArgs e)
		{
			int rowIndex = dgv_clientes.CurrentCell.RowIndex;
			dgv_pedidos.DataSource = dao.listar_pedido(dgv_clientes.CurrentRow.Cells[1].Value.ToString());
		}

		private void btn_saindo_Click(object sender, EventArgs e)
		{
			int rowIndex = dgv_pedidos.CurrentCell.RowIndex;
			dao.statussaindo(dgv_pedidos.CurrentRow.Cells[0].Value.ToString(), int.Parse(dgv_pedidos.CurrentRow.Cells[1].Value.ToString()));
			dgv_pedidos.DataSource = dao.listar_pedido(dgv_clientes.CurrentRow.Cells[1].Value.ToString());
			dgv_clientes.DataSource = dao.listar_clientes();
		}

		private void btn_entregue_Click(object sender, EventArgs e)
		{
			int rowIndex = dgv_pedidos.CurrentCell.RowIndex;
			dao.statusentregue(dgv_pedidos.CurrentRow.Cells[0].Value.ToString(), int.Parse(dgv_pedidos.CurrentRow.Cells[1].Value.ToString()));
			dgv_pedidos.DataSource = dao.listar_pedido(dgv_clientes.CurrentRow.Cells[1].Value.ToString());
			dgv_clientes.DataSource = dao.listar_clientes();
		}

		private void btn_atualizar_Click(object sender, EventArgs e)
		{
			dgv_pagamento.DataSource = dao.listar_pagamento(dgv_clientes.CurrentRow.Cells[1].Value.ToString());
			dgv_clientes.DataSource = dao.listar_clientes();
		}

		private void btn_fechar_Click(object sender, EventArgs e)
		{
			int rowIndex = dgv_pagamento.CurrentCell.RowIndex;
			dao.pago(dgv_pagamento.CurrentRow.Cells[0].Value.ToString());
			dgv_pagamento.DataSource = dao.listar_pagamento(dgv_clientes.CurrentRow.Cells[1].Value.ToString());
		}
	}
}
