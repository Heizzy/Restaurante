﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
	public partial class frm_status : Form
	{
        DAO dao = new DAO();
        string cpf;

        public frm_status(string cpf)
		{
			InitializeComponent();
            this.cpf = cpf;
            dgv_status.AutoGenerateColumns = false;
        }

		private void exit_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void minimize_Click(object sender, EventArgs e)
		{
			this.WindowState = FormWindowState.Minimized;
		}

        private void frm_status_Load(object sender, EventArgs e)
        {
            dgv_status.DataSource = dao.listar_pedido(cpf);
        }

        private void btn_comprar_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_menu menu = new frm_menu(cpf);
            menu.Show();
            menu.Closed += (s, args) => this.Close();
        }

        private void btn_fecharconta_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_fechar fechar = new frm_fechar(cpf);
            fechar.Show();
            fechar.Closed += (s, args) => this.Close();
        }
    }
}
