﻿namespace WindowsFormsApplication1
{
    partial class frm_cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_cliente));
			this.btn_nextn = new System.Windows.Forms.Button();
			this.txt_name = new System.Windows.Forms.TextBox();
			this.lbl_nome = new System.Windows.Forms.Label();
			this.lblcpf = new System.Windows.Forms.Label();
			this.txtcpf = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.minimize = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btn_nextn
			// 
			this.btn_nextn.BackColor = System.Drawing.Color.Transparent;
			this.btn_nextn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_nextn.BackgroundImage")));
			this.btn_nextn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.btn_nextn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btn_nextn.FlatAppearance.BorderSize = 0;
			this.btn_nextn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
			this.btn_nextn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
			this.btn_nextn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_nextn.Font = new System.Drawing.Font("Open Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_nextn.Location = new System.Drawing.Point(131, 303);
			this.btn_nextn.Name = "btn_nextn";
			this.btn_nextn.Size = new System.Drawing.Size(190, 60);
			this.btn_nextn.TabIndex = 3;
			this.btn_nextn.Text = "Continue";
			this.btn_nextn.UseVisualStyleBackColor = false;
			this.btn_nextn.Click += new System.EventHandler(this.btn_nextn_Click);
			// 
			// txt_name
			// 
			this.txt_name.Location = new System.Drawing.Point(148, 246);
			this.txt_name.Name = "txt_name";
			this.txt_name.Size = new System.Drawing.Size(159, 20);
			this.txt_name.TabIndex = 1;
			this.txt_name.TextChanged += new System.EventHandler(this.txt_nome_TextChanged);
			// 
			// lbl_nome
			// 
			this.lbl_nome.AutoSize = true;
			this.lbl_nome.Location = new System.Drawing.Point(96, 249);
			this.lbl_nome.Name = "lbl_nome";
			this.lbl_nome.Size = new System.Drawing.Size(42, 13);
			this.lbl_nome.TabIndex = 4;
			this.lbl_nome.Text = "NOME:";
			// 
			// lblcpf
			// 
			this.lblcpf.AutoSize = true;
			this.lblcpf.Location = new System.Drawing.Point(96, 281);
			this.lblcpf.Name = "lblcpf";
			this.lblcpf.Size = new System.Drawing.Size(30, 13);
			this.lblcpf.TabIndex = 7;
			this.lblcpf.Text = "CPF:";
			// 
			// txtcpf
			// 
			this.txtcpf.Location = new System.Drawing.Point(148, 277);
			this.txtcpf.MaxLength = 11;
			this.txtcpf.Name = "txtcpf";
			this.txtcpf.Size = new System.Drawing.Size(159, 20);
			this.txtcpf.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(50, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(355, 44);
			this.label1.TabIndex = 8;
			this.label1.Text = "Precisamos de algumas informações antes.\r\nNão se preocupe, é rápido!\r\n";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
			this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox1.Location = new System.Drawing.Point(159, 94);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(137, 137);
			this.pictureBox1.TabIndex = 9;
			this.pictureBox1.TabStop = false;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.DarkRed;
			this.panel2.Controls.Add(this.pictureBox1);
			this.panel2.Controls.Add(this.label1);
			this.panel2.Controls.Add(this.txtcpf);
			this.panel2.Controls.Add(this.lblcpf);
			this.panel2.Controls.Add(this.txt_name);
			this.panel2.Controls.Add(this.lbl_nome);
			this.panel2.Controls.Add(this.btn_nextn);
			this.panel2.Location = new System.Drawing.Point(213, 62);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(441, 421);
			this.panel2.TabIndex = 10;
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.minimize.Location = new System.Drawing.Point(830, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 3;
			this.minimize.Text = "▁";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
			this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
			this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.exit.Location = new System.Drawing.Point(855, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 4;
			this.exit.Text = "✕";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(880, 25);
			this.panel1.TabIndex = 11;
			// 
			// frm_cliente
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(880, 550);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm_cliente";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "nome";
			this.Load += new System.EventHandler(this.nome_Load);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_nextn;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label lbl_nome;
        private System.Windows.Forms.Label lblcpf;
        private System.Windows.Forms.TextBox txtcpf;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button minimize;
		private System.Windows.Forms.Button exit;
		private System.Windows.Forms.Panel panel1;
	}
}