﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{

    class Cliente : Pessoa
    {
        public string mesa = "1";
		public int pagamento = 1;
        DAO dao = new DAO();
		public bool verify;
        

        public void cadcliente(string nome, string cpf)
        {
           dao.cad_cliente(cpf, nome, pagamento, mesa);
        }

		public bool vrycliente(string nome, string cpf)
		{
			verify = dao.vry_cliente(cpf, nome, mesa);
			return verify;
		}
    }
}