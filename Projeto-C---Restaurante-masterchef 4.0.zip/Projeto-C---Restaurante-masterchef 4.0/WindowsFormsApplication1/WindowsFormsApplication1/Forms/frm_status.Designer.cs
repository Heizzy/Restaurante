﻿namespace WindowsFormsApplication1
{
	partial class frm_status
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.minimize = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgv_status = new System.Windows.Forms.DataGridView();
            this.col_codPr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_quant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_comprar = new System.Windows.Forms.Button();
            this.btn_fecharconta = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_status)).BeginInit();
            this.SuspendLayout();
            // 
            // minimize
            // 
            this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimize.Location = new System.Drawing.Point(970, 0);
            this.minimize.Name = "minimize";
            this.minimize.Size = new System.Drawing.Size(25, 25);
            this.minimize.TabIndex = 3;
            this.minimize.Text = "▁";
            this.minimize.UseVisualStyleBackColor = true;
            this.minimize.Click += new System.EventHandler(this.minimize_Click);
            // 
            // exit
            // 
            this.exit.Dock = System.Windows.Forms.DockStyle.Right;
            this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.Location = new System.Drawing.Point(995, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(25, 25);
            this.exit.TabIndex = 4;
            this.exit.Text = "✕";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.minimize);
            this.panel1.Controls.Add(this.exit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1020, 25);
            this.panel1.TabIndex = 3;
            // 
            // dgv_status
            // 
            this.dgv_status.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_status.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_codPr,
            this.col_quant,
            this.col_status});
            this.dgv_status.Location = new System.Drawing.Point(0, 25);
            this.dgv_status.Name = "dgv_status";
            this.dgv_status.Size = new System.Drawing.Size(1020, 307);
            this.dgv_status.TabIndex = 4;
            // 
            // col_codPr
            // 
            this.col_codPr.DataPropertyName = "nome_pr";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.col_codPr.DefaultCellStyle = dataGridViewCellStyle1;
            this.col_codPr.HeaderText = "Nome";
            this.col_codPr.Name = "col_codPr";
            this.col_codPr.Width = 292;
            // 
            // col_quant
            // 
            this.col_quant.DataPropertyName = "quant_pr";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.col_quant.DefaultCellStyle = dataGridViewCellStyle2;
            this.col_quant.HeaderText = "Quantidade";
            this.col_quant.Name = "col_quant";
            this.col_quant.Width = 292;
            // 
            // col_status
            // 
            this.col_status.DataPropertyName = "status_pedido";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.col_status.DefaultCellStyle = dataGridViewCellStyle3;
            this.col_status.HeaderText = "Status";
            this.col_status.Name = "col_status";
            this.col_status.Width = 393;
            // 
            // btn_comprar
            // 
            this.btn_comprar.Location = new System.Drawing.Point(213, 402);
            this.btn_comprar.Name = "btn_comprar";
            this.btn_comprar.Size = new System.Drawing.Size(121, 23);
            this.btn_comprar.TabIndex = 5;
            this.btn_comprar.Text = "Continuar comprando";
            this.btn_comprar.UseVisualStyleBackColor = true;
            this.btn_comprar.Click += new System.EventHandler(this.btn_comprar_Click);
            // 
            // btn_fecharconta
            // 
            this.btn_fecharconta.Location = new System.Drawing.Point(683, 402);
            this.btn_fecharconta.Name = "btn_fecharconta";
            this.btn_fecharconta.Size = new System.Drawing.Size(87, 23);
            this.btn_fecharconta.TabIndex = 6;
            this.btn_fecharconta.Text = "Fechar conta";
            this.btn_fecharconta.UseVisualStyleBackColor = true;
            this.btn_fecharconta.Click += new System.EventHandler(this.btn_fecharconta_Click);
            // 
            // frm_status
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 510);
            this.Controls.Add(this.btn_fecharconta);
            this.Controls.Add(this.btn_comprar);
            this.Controls.Add(this.dgv_status);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frm_status";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_status";
            this.Load += new System.EventHandler(this.frm_status_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_status)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button minimize;
		private System.Windows.Forms.Button exit;
		private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgv_status;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_codPr;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_quant;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_status;
        private System.Windows.Forms.Button btn_comprar;
        private System.Windows.Forms.Button btn_fecharconta;
    }
}