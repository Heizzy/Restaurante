﻿namespace WindowsFormsApplication1
{
    partial class frm_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			this.panel1 = new System.Windows.Forms.Panel();
			this.minimize = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.btn_final = new System.Windows.Forms.Panel();
			this.btn_fiinal = new System.Windows.Forms.Button();
			this.lbl_total = new System.Windows.Forms.DataGridView();
			this.col_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colPr = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.col_preco = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colquant = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.brn_remquant = new System.Windows.Forms.Button();
			this.pn_menu = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.btn_addPedido = new System.Windows.Forms.Button();
			this.dgv_Menu = new System.Windows.Forms.DataGridView();
			this.pn_btns = new System.Windows.Forms.Panel();
			this.btn_beb = new System.Windows.Forms.Button();
			this.btn_sob = new System.Windows.Forms.Button();
			this.btn_pr = new System.Windows.Forms.Button();
			this.panel3 = new System.Windows.Forms.Panel();
			this.pn_indice = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.lbl_totalPay = new System.Windows.Forms.Label();
			this.colIdPedido = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colValor = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel1.SuspendLayout();
			this.btn_final.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.lbl_total)).BeginInit();
			this.pn_menu.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgv_Menu)).BeginInit();
			this.pn_btns.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.minimize);
			this.panel1.Controls.Add(this.exit);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1099, 25);
			this.panel1.TabIndex = 3;
			// 
			// minimize
			// 
			this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
			this.minimize.FlatAppearance.BorderSize = 0;
			this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.minimize.Location = new System.Drawing.Point(1049, 0);
			this.minimize.Name = "minimize";
			this.minimize.Size = new System.Drawing.Size(25, 25);
			this.minimize.TabIndex = 2;
			this.minimize.Text = "_";
			this.minimize.UseVisualStyleBackColor = true;
			this.minimize.Click += new System.EventHandler(this.minimize_Click);
			// 
			// exit
			// 
			this.exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.exit.FlatAppearance.BorderSize = 0;
			this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
			this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.exit.Location = new System.Drawing.Point(1074, 0);
			this.exit.Name = "exit";
			this.exit.Size = new System.Drawing.Size(25, 25);
			this.exit.TabIndex = 1;
			this.exit.Text = "x";
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// btn_final
			// 
			this.btn_final.BackColor = System.Drawing.Color.DarkRed;
			this.btn_final.Controls.Add(this.lbl_totalPay);
			this.btn_final.Controls.Add(this.label1);
			this.btn_final.Controls.Add(this.btn_fiinal);
			this.btn_final.Controls.Add(this.lbl_total);
			this.btn_final.Dock = System.Windows.Forms.DockStyle.Right;
			this.btn_final.Location = new System.Drawing.Point(706, 25);
			this.btn_final.Name = "btn_final";
			this.btn_final.Size = new System.Drawing.Size(393, 524);
			this.btn_final.TabIndex = 4;
			// 
			// btn_fiinal
			// 
			this.btn_fiinal.Location = new System.Drawing.Point(271, 468);
			this.btn_fiinal.Name = "btn_fiinal";
			this.btn_fiinal.Size = new System.Drawing.Size(102, 35);
			this.btn_fiinal.TabIndex = 1;
			this.btn_fiinal.Text = "Finalizar pedido";
			this.btn_fiinal.UseVisualStyleBackColor = true;
			this.btn_fiinal.Click += new System.EventHandler(this.btn_fiinal_Click);
			// 
			// lbl_total
			// 
			this.lbl_total.AllowUserToAddRows = false;
			this.lbl_total.AllowUserToDeleteRows = false;
			this.lbl_total.BackgroundColor = System.Drawing.Color.White;
			this.lbl_total.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.lbl_total.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_id,
            this.colPr,
            this.col_preco,
            this.colquant});
			this.lbl_total.Location = new System.Drawing.Point(22, 50);
			this.lbl_total.Name = "lbl_total";
			this.lbl_total.ReadOnly = true;
			this.lbl_total.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.lbl_total.Size = new System.Drawing.Size(346, 387);
			this.lbl_total.TabIndex = 0;
			// 
			// col_id
			// 
			this.col_id.DataPropertyName = "cod_pr";
			this.col_id.HeaderText = "ID";
			this.col_id.Name = "col_id";
			this.col_id.ReadOnly = true;
			this.col_id.Visible = false;
			// 
			// colPr
			// 
			this.colPr.DataPropertyName = "nome_pr";
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.colPr.DefaultCellStyle = dataGridViewCellStyle1;
			this.colPr.HeaderText = "Prato";
			this.colPr.Name = "colPr";
			this.colPr.ReadOnly = true;
			// 
			// col_preco
			// 
			this.col_preco.DataPropertyName = "valor_pr";
			this.col_preco.HeaderText = "Preço";
			this.col_preco.Name = "col_preco";
			this.col_preco.ReadOnly = true;
			// 
			// colquant
			// 
			this.colquant.DataPropertyName = "quant_pr";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Open Sans", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.colquant.DefaultCellStyle = dataGridViewCellStyle2;
			this.colquant.HeaderText = "Quantidade";
			this.colquant.Name = "colquant";
			this.colquant.ReadOnly = true;
			// 
			// brn_remquant
			// 
			this.brn_remquant.Location = new System.Drawing.Point(362, 19);
			this.brn_remquant.Name = "brn_remquant";
			this.brn_remquant.Size = new System.Drawing.Size(234, 35);
			this.brn_remquant.TabIndex = 3;
			this.brn_remquant.Text = "Remover";
			this.brn_remquant.UseVisualStyleBackColor = true;
			this.brn_remquant.Click += new System.EventHandler(this.brn_remquant_Click);
			// 
			// pn_menu
			// 
			this.pn_menu.Controls.Add(this.panel2);
			this.pn_menu.Controls.Add(this.dgv_Menu);
			this.pn_menu.Dock = System.Windows.Forms.DockStyle.Top;
			this.pn_menu.Location = new System.Drawing.Point(0, 75);
			this.pn_menu.Name = "pn_menu";
			this.pn_menu.Size = new System.Drawing.Size(706, 474);
			this.pn_menu.TabIndex = 5;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Black;
			this.panel2.Controls.Add(this.brn_remquant);
			this.panel2.Controls.Add(this.btn_addPedido);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel2.Location = new System.Drawing.Point(0, 399);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(706, 75);
			this.panel2.TabIndex = 1;
			// 
			// btn_addPedido
			// 
			this.btn_addPedido.Location = new System.Drawing.Point(70, 19);
			this.btn_addPedido.Name = "btn_addPedido";
			this.btn_addPedido.Size = new System.Drawing.Size(234, 35);
			this.btn_addPedido.TabIndex = 0;
			this.btn_addPedido.Text = "Adicionar";
			this.btn_addPedido.UseVisualStyleBackColor = true;
			this.btn_addPedido.Click += new System.EventHandler(this.btn_addPedido_Click);
			// 
			// dgv_Menu
			// 
			this.dgv_Menu.AllowUserToAddRows = false;
			this.dgv_Menu.AllowUserToDeleteRows = false;
			this.dgv_Menu.BackgroundColor = System.Drawing.Color.White;
			this.dgv_Menu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dgv_Menu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colIdPedido,
            this.colNome,
            this.colValor,
            this.colDesc});
			this.dgv_Menu.Cursor = System.Windows.Forms.Cursors.Hand;
			this.dgv_Menu.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgv_Menu.GridColor = System.Drawing.Color.White;
			this.dgv_Menu.Location = new System.Drawing.Point(0, 0);
			this.dgv_Menu.Name = "dgv_Menu";
			this.dgv_Menu.ReadOnly = true;
			this.dgv_Menu.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgv_Menu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgv_Menu.Size = new System.Drawing.Size(706, 474);
			this.dgv_Menu.TabIndex = 0;
			// 
			// pn_btns
			// 
			this.pn_btns.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.pn_btns.Controls.Add(this.btn_beb);
			this.pn_btns.Controls.Add(this.btn_sob);
			this.pn_btns.Controls.Add(this.btn_pr);
			this.pn_btns.Dock = System.Windows.Forms.DockStyle.Top;
			this.pn_btns.Location = new System.Drawing.Point(0, 25);
			this.pn_btns.Name = "pn_btns";
			this.pn_btns.Size = new System.Drawing.Size(706, 40);
			this.pn_btns.TabIndex = 6;
			// 
			// btn_beb
			// 
			this.btn_beb.BackColor = System.Drawing.Color.Black;
			this.btn_beb.Dock = System.Windows.Forms.DockStyle.Right;
			this.btn_beb.FlatAppearance.BorderSize = 0;
			this.btn_beb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_beb.ForeColor = System.Drawing.Color.White;
			this.btn_beb.Location = new System.Drawing.Point(472, 0);
			this.btn_beb.Name = "btn_beb";
			this.btn_beb.Size = new System.Drawing.Size(234, 40);
			this.btn_beb.TabIndex = 10;
			this.btn_beb.Text = "SOBREMESAS";
			this.btn_beb.UseVisualStyleBackColor = false;
			this.btn_beb.Click += new System.EventHandler(this.btn_beb_Click_1);
			// 
			// btn_sob
			// 
			this.btn_sob.BackColor = System.Drawing.Color.Black;
			this.btn_sob.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn_sob.FlatAppearance.BorderSize = 0;
			this.btn_sob.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_sob.ForeColor = System.Drawing.Color.White;
			this.btn_sob.Location = new System.Drawing.Point(234, 0);
			this.btn_sob.Name = "btn_sob";
			this.btn_sob.Size = new System.Drawing.Size(234, 40);
			this.btn_sob.TabIndex = 9;
			this.btn_sob.Text = "BEBIDAS";
			this.btn_sob.UseVisualStyleBackColor = false;
			this.btn_sob.Click += new System.EventHandler(this.btn_sob_Click_1);
			// 
			// btn_pr
			// 
			this.btn_pr.BackColor = System.Drawing.Color.Black;
			this.btn_pr.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn_pr.FlatAppearance.BorderSize = 0;
			this.btn_pr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_pr.ForeColor = System.Drawing.Color.White;
			this.btn_pr.Location = new System.Drawing.Point(0, 0);
			this.btn_pr.Name = "btn_pr";
			this.btn_pr.Size = new System.Drawing.Size(234, 40);
			this.btn_pr.TabIndex = 8;
			this.btn_pr.Text = "PRATOS";
			this.btn_pr.UseVisualStyleBackColor = false;
			this.btn_pr.Click += new System.EventHandler(this.btn_pr_Click_1);
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.pn_indice);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel3.Location = new System.Drawing.Point(0, 65);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(706, 10);
			this.panel3.TabIndex = 7;
			// 
			// pn_indice
			// 
			this.pn_indice.BackColor = System.Drawing.Color.OrangeRed;
			this.pn_indice.Location = new System.Drawing.Point(0, 0);
			this.pn_indice.Name = "pn_indice";
			this.pn_indice.Size = new System.Drawing.Size(234, 10);
			this.pn_indice.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Open Sans", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(22, 475);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(107, 28);
			this.label1.TabIndex = 2;
			this.label1.Text = "Total : R$";
			// 
			// lbl_totalPay
			// 
			this.lbl_totalPay.AutoSize = true;
			this.lbl_totalPay.Font = new System.Drawing.Font("Open Sans", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_totalPay.Location = new System.Drawing.Point(125, 475);
			this.lbl_totalPay.Name = "lbl_totalPay";
			this.lbl_totalPay.Size = new System.Drawing.Size(66, 28);
			this.lbl_totalPay.TabIndex = 3;
			this.lbl_totalPay.Text = "00,00";
			// 
			// colIdPedido
			// 
			this.colIdPedido.DataPropertyName = "cod_pr";
			this.colIdPedido.HeaderText = "ID";
			this.colIdPedido.Name = "colIdPedido";
			this.colIdPedido.ReadOnly = true;
			this.colIdPedido.Visible = false;
			// 
			// colNome
			// 
			this.colNome.DataPropertyName = "nome_pr";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.colNome.DefaultCellStyle = dataGridViewCellStyle3;
			this.colNome.HeaderText = "Pratos";
			this.colNome.Name = "colNome";
			this.colNome.ReadOnly = true;
			this.colNome.Width = 220;
			// 
			// colValor
			// 
			this.colValor.DataPropertyName = "valor_pr";
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.colValor.DefaultCellStyle = dataGridViewCellStyle4;
			this.colValor.HeaderText = "Preços";
			this.colValor.Name = "colValor";
			this.colValor.ReadOnly = true;
			this.colValor.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.colValor.Width = 220;
			// 
			// colDesc
			// 
			this.colDesc.DataPropertyName = "desc_pr";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle5.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.colDesc.DefaultCellStyle = dataGridViewCellStyle5;
			this.colDesc.HeaderText = "Descrições";
			this.colDesc.Name = "colDesc";
			this.colDesc.ReadOnly = true;
			this.colDesc.Width = 220;
			// 
			// frm_menu
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1099, 549);
			this.Controls.Add(this.pn_menu);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.pn_btns);
			this.Controls.Add(this.btn_final);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm_menu";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Load += new System.EventHandler(this.frm_menu_Load);
			this.panel1.ResumeLayout(false);
			this.btn_final.ResumeLayout(false);
			this.btn_final.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.lbl_total)).EndInit();
			this.pn_menu.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgv_Menu)).EndInit();
			this.pn_btns.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
		private System.Windows.Forms.Panel btn_final;
		private System.Windows.Forms.Panel pn_menu;
		private System.Windows.Forms.Panel pn_btns;
		private System.Windows.Forms.Button btn_beb;
		private System.Windows.Forms.Button btn_sob;
		private System.Windows.Forms.Button btn_pr;
		private System.Windows.Forms.DataGridView dgv_Menu;
		private System.Windows.Forms.DataGridView lbl_total;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btn_addPedido;
		private System.Windows.Forms.Button btn_fiinal;
		private System.Windows.Forms.Button brn_remquant;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel pn_indice;
		private System.Windows.Forms.DataGridViewTextBoxColumn col_id;
		private System.Windows.Forms.DataGridViewTextBoxColumn colPr;
		private System.Windows.Forms.DataGridViewTextBoxColumn col_preco;
		private System.Windows.Forms.DataGridViewTextBoxColumn colquant;
		private System.Windows.Forms.Label lbl_totalPay;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DataGridViewTextBoxColumn colIdPedido;
		private System.Windows.Forms.DataGridViewTextBoxColumn colNome;
		private System.Windows.Forms.DataGridViewTextBoxColumn colValor;
		private System.Windows.Forms.DataGridViewTextBoxColumn colDesc;
	}
}