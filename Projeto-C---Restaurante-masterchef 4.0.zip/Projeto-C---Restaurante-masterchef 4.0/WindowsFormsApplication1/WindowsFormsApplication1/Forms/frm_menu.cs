﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frm_menu : Form
    {
		DAO dao = new  DAO();
		Pedido pedido = new Pedido();
		public string cpf;
		public string status;
		public float resultado;

		public frm_menu(string cpf)
        {
            InitializeComponent();
			this.cpf = cpf;
			dgv_Menu.AutoGenerateColumns = false;
			lbl_total.AutoGenerateColumns = false;
		}

        private void exit_Click(object sender, EventArgs e)
        {
			dao.clear(cpf);
            Application.Exit();
        }

		private void minimize_Click(object sender, EventArgs e)
		{
			this.WindowState = FormWindowState.Minimized;
		}

		private void frm_menu_Load(object sender, EventArgs e)
		{
			dgv_Menu.DataSource = dao.listar_pratos();
			status = "Não finalizado";
		}

		private void btn_addPedido_Click(object sender, EventArgs e)
		{
			int rowIndex = dgv_Menu.CurrentCell.RowIndex;
			pedido.listpedido(cpf, int.Parse(dgv_Menu.CurrentRow.Cells[0].Value.ToString()), dgv_Menu.CurrentRow.Cells[1].Value.ToString(), float.Parse(dgv_Menu.CurrentRow.Cells[2].Value.ToString()), status);


			lbl_totalPay.Text = pedido.total(cpf).ToString();
			lbl_total.DataSource = dao.listar_pedido(cpf);
		}

		private void brn_remquant_Click(object sender, EventArgs e)
		{
            if (lbl_total.CurrentCell != null)
            {
                int rowIndex = lbl_total.CurrentCell.RowIndex;
                pedido.remQuant(cpf, int.Parse(dgv_Menu.CurrentRow.Cells[0].Value.ToString()), float.Parse(dgv_Menu.CurrentRow.Cells[2].Value.ToString()));
                lbl_total.DataSource = dao.listar_pedido(cpf);
            }
		}

		private void btn_fiinal_Click(object sender, EventArgs e)
		{
            pedido.finality(cpf);
            this.Hide();
            frm_status status = new frm_status(cpf);
            status.Show();
            status.Closed += (s, args) => this.Close();
        }

		private void btn_sob_Click_1(object sender, EventArgs e)
		{
			dgv_Menu.DataSource = dao.listar_bebidas();
		}

		private void btn_pr_Click_1(object sender, EventArgs e)
		{
			dgv_Menu.DataSource = dao.listar_comidas();
		}

		private void btn_beb_Click_1(object sender, EventArgs e)
		{
			dgv_Menu.DataSource = dao.listar_sobremesas();
		}
	}
}
